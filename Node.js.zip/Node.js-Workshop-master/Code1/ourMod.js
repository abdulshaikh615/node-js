var x = Date();

exports.ourMod = x;
