var os = require('os');
console.log("Platform: " + os.platform());
console.log("Architecture: " + os.arch());
console.log("Name: " + os.type());
console.log("Release version: " + os.release());
console.log("Uptime: " + os.uptime());

