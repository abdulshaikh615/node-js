module.exports = {   
    firstname: 'Bill',   
    lastname: 'Gates',   
    getFullName: function(){ 
        return `${this.firstname} ${this.lastname}` 
    } 
}